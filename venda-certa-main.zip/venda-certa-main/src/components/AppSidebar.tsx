import { NavLink, useLocation } from 'react-router-dom';
import { LayoutDashboard, Package, Warehouse, Receipt, Calculator, X, Menu, TrendingUp, ShoppingCart, Users, CreditCard, FileText, ArrowLeftRight, Wallet, HandCoins, UserCheck, BarChart3, RefreshCw, Target, Shield, PieChart } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useState } from 'react';

const sections = [
  {
    label: 'Principal',
    links: [
      { to: '/', icon: LayoutDashboard, label: 'Dashboard' },
      { to: '/metas', icon: Target, label: 'Metas' },
    ],
  },
  {
    label: 'Comercial',
    links: [
      { to: '/caixa', icon: ShoppingCart, label: 'Caixa / PDV' },
      { to: '/clientes', icon: UserCheck, label: 'Clientes' },
      { to: '/concorrencia', icon: TrendingUp, label: 'Concorrência' },
    ],
  },
  {
    label: 'Produtos',
    links: [
      { to: '/produtos', icon: Package, label: 'Produtos' },
      { to: '/estoque', icon: Warehouse, label: 'Estoque' },
      { to: '/movimentacoes', icon: ArrowLeftRight, label: 'Movimentações' },
      { to: '/reposicao', icon: RefreshCw, label: 'Reposição' },
    ],
  },
  {
    label: 'Financeiro',
    links: [
      { to: '/fluxo-caixa', icon: Wallet, label: 'Fluxo de Caixa' },
      { to: '/contas-receber', icon: HandCoins, label: 'Contas a Receber' },
      { to: '/contas-pagar', icon: CreditCard, label: 'Contas a Pagar' },
      { to: '/custos', icon: Receipt, label: 'Custos' },
    ],
  },
  {
    label: 'Análises',
    links: [
      { to: '/precificacao', icon: Calculator, label: 'Precificação' },
      { to: '/rentabilidade', icon: BarChart3, label: 'Rentabilidade' },
      { to: '/curva-abc', icon: PieChart, label: 'Curva ABC' },
    ],
  },
  {
    label: 'Operações',
    links: [
      { to: '/fornecedores', icon: Users, label: 'Fornecedores' },
      { to: '/notas-fiscais', icon: FileText, label: 'Notas Fiscais' },
      { to: '/auditoria', icon: Shield, label: 'Auditoria' },
    ],
  },
];

export default function AppSidebar() {
  const [open, setOpen] = useState(false);
  const location = useLocation();

  return (
    <>
      <button
        onClick={() => setOpen(true)}
        className="fixed top-4 left-4 z-50 lg:hidden p-2 rounded-lg bg-card border border-border shadow-sm"
      >
        <Menu className="h-5 w-5 text-foreground" />
      </button>

      {open && (
        <div className="fixed inset-0 bg-black/20 z-40 lg:hidden" onClick={() => setOpen(false)} />
      )}

      <aside
        className={cn(
          "fixed top-0 left-0 z-50 h-full w-60 bg-card border-r border-border flex flex-col transition-transform duration-200",
          "lg:translate-x-0 lg:static lg:z-auto",
          open ? "translate-x-0" : "-translate-x-full"
        )}
      >
        <div className="flex items-center justify-between p-5 pb-2">
          <div>
            <h1 className="text-lg font-bold text-foreground tracking-tight">GestãoClara</h1>
            <p className="text-xs text-muted-foreground">Gestão simplificada</p>
          </div>
          <button onClick={() => setOpen(false)} className="lg:hidden p-1 text-muted-foreground hover:text-foreground">
            <X className="h-5 w-5" />
          </button>
        </div>

        <nav className="flex-1 px-3 py-3 space-y-4 overflow-y-auto">
          {sections.map(section => (
            <div key={section.label}>
              <p className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider px-3 mb-1">{section.label}</p>
              <div className="space-y-0.5">
                {section.links.map(({ to, icon: Icon, label }) => {
                  const active = location.pathname === to;
                  return (
                    <NavLink
                      key={to}
                      to={to}
                      onClick={() => setOpen(false)}
                      className={cn(
                        "flex items-center gap-2.5 px-3 py-1.5 rounded-lg text-[13px] font-medium transition-colors",
                        active
                          ? "bg-primary text-primary-foreground"
                          : "text-muted-foreground hover:text-foreground hover:bg-accent"
                      )}
                    >
                      <Icon className="h-3.5 w-3.5" />
                      {label}
                    </NavLink>
                  );
                })}
              </div>
            </div>
          ))}
        </nav>

        <div className="p-3 mx-3 mb-3 rounded-lg bg-accent">
          <p className="text-xs font-medium text-accent-foreground">Dados locais</p>
          <p className="text-[11px] text-muted-foreground mt-0.5">Salvos neste navegador.</p>
        </div>
      </aside>
    </>
  );
}
