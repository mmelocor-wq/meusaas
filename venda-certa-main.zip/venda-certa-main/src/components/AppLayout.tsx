import AppSidebar from './AppSidebar';

export default function AppLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex min-h-screen bg-background">
      <AppSidebar />
      <main className="flex-1 lg:ml-0 overflow-auto">
        <div className="max-w-6xl mx-auto p-4 pt-16 lg:pt-6 lg:p-8">
          {children}
        </div>
      </main>
    </div>
  );
}
