import { useEffect, useState } from 'react';
import AppLayout from '@/components/AppLayout';
import { getProducts, updateProduct, type Product } from '@/lib/store';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { AlertTriangle, Minus, Plus, Search } from 'lucide-react';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';

export default function Inventory() {
  const [products, setProducts] = useState<Product[]>([]);
  const [search, setSearch] = useState('');

  const reload = () => setProducts(getProducts());
  useEffect(reload, []);

  const filtered = products.filter(p =>
    p.name.toLowerCase().includes(search.toLowerCase()) ||
    p.category.toLowerCase().includes(search.toLowerCase())
  );

  const adjustStock = (id: string, delta: number) => {
    const p = products.find(pr => pr.id === id);
    if (!p) return;
    const newStock = Math.max(0, p.stock + delta);
    updateProduct(id, { stock: newStock });
    toast.success(`Estoque atualizado: ${p.name} → ${newStock} ${p.unit}`);
    reload();
  };

  const lowStockProducts = products.filter(p => p.stock <= p.minStock);

  return (
    <AppLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Estoque</h1>
          <p className="text-muted-foreground text-sm mt-1">Controle entradas e saídas rapidamente</p>
        </div>

        {lowStockProducts.length > 0 && (
          <div className="rounded-xl border border-destructive/30 bg-destructive/5 p-4">
            <div className="flex items-center gap-2 mb-2">
              <AlertTriangle className="h-4 w-4 text-destructive" />
              <span className="text-sm font-semibold text-destructive">{lowStockProducts.length} produto(s) com estoque baixo</span>
            </div>
            <p className="text-xs text-muted-foreground">
              {lowStockProducts.map(p => p.name).join(', ')}
            </p>
          </div>
        )}

        <div className="relative max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Buscar produto..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map(p => {
            const lowStock = p.stock <= p.minStock;
            return (
              <div key={p.id} className={cn(
                "rounded-xl border bg-card p-4 space-y-3",
                lowStock ? 'border-destructive/40' : 'border-border'
              )}>
                <div>
                  <h3 className="font-semibold text-foreground text-sm">{p.name}</h3>
                  <p className="text-xs text-muted-foreground">{p.category}</p>
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <p className={cn("text-2xl font-bold", lowStock ? 'text-destructive' : 'text-foreground')}>
                      {p.stock}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {p.unit} · mín: {p.minStock}
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => adjustStock(p.id, -1)}>
                      <Minus className="h-3.5 w-3.5" />
                    </Button>
                    <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => adjustStock(p.id, 1)}>
                      <Plus className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                </div>
                {lowStock && (
                  <div className="flex items-center gap-1.5 text-xs text-destructive">
                    <AlertTriangle className="h-3 w-3" />
                    Estoque abaixo do mínimo
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {filtered.length === 0 && (
          <div className="text-center py-12 text-muted-foreground">Nenhum produto encontrado.</div>
        )}
      </div>
    </AppLayout>
  );
}
