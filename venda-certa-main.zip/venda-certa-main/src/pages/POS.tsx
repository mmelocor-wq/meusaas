import { useEffect, useState, useRef } from 'react';
import AppLayout from '@/components/AppLayout';
import { getProducts, addSale, findProductByBarcode, getSales, getCustomers, type Product, type SaleItem, type Sale, type Customer, fmt } from '@/lib/store';
import { ShoppingCart, Plus, Minus, Trash2, Search, Barcode, CheckCircle, User } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';

export default function POS() {
  const [products, setProducts] = useState<Product[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [cart, setCart] = useState<SaleItem[]>([]);
  const [search, setSearch] = useState('');
  const [barcodeInput, setBarcodeInput] = useState('');
  const [sales, setSales] = useState<Sale[]>([]);
  const [showHistory, setShowHistory] = useState(false);
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
  const barcodeRef = useRef<HTMLInputElement>(null);

  const reload = () => { setProducts(getProducts()); setSales(getSales()); setCustomers(getCustomers()); };
  useEffect(reload, []);

  const addToCart = (product: Product, qty = 1) => {
    if (product.stock < qty) { toast.error(`Estoque insuficiente: ${product.stock} ${product.unit}`); return; }
    const existing = cart.find(i => i.productId === product.id);
    if (existing) {
      const newQty = existing.quantity + qty;
      if (newQty > product.stock) { toast.error('Estoque insuficiente'); return; }
      setCart(cart.map(i => i.productId === product.id ? { ...i, quantity: newQty, subtotal: newQty * i.unitPrice } : i));
    } else {
      setCart([...cart, { productId: product.id, productName: product.name, quantity: qty, unitPrice: product.salePrice, subtotal: product.salePrice * qty }]);
    }
  };

  const updateQty = (productId: string, delta: number) => {
    const product = products.find(p => p.id === productId);
    setCart(prev => prev.map(i => {
      if (i.productId !== productId) return i;
      const newQty = i.quantity + delta;
      if (newQty <= 0) return i;
      if (product && newQty > product.stock) { toast.error('Estoque insuficiente'); return i; }
      return { ...i, quantity: newQty, subtotal: newQty * i.unitPrice };
    }));
  };

  const removeFromCart = (productId: string) => setCart(cart.filter(i => i.productId !== productId));

  const handleBarcode = (e: React.FormEvent) => {
    e.preventDefault();
    if (!barcodeInput.trim()) return;
    const product = findProductByBarcode(barcodeInput.trim());
    if (product) { addToCart(product); toast.success(`${product.name} adicionado`); }
    else toast.error('Produto não encontrado');
    setBarcodeInput('');
    barcodeRef.current?.focus();
  };

  const finalizeSale = () => {
    if (cart.length === 0) { toast.error('Carrinho vazio'); return; }
    addSale(cart, 'Operador', selectedCustomer?.id, selectedCustomer?.name);
    setCart([]);
    setSelectedCustomer(null);
    toast.success('Venda finalizada com sucesso!');
    reload();
  };

  const total = cart.reduce((s, i) => s + i.subtotal, 0);
  const filtered = products.filter(p => p.name.toLowerCase().includes(search.toLowerCase()) || p.barcode?.includes(search));

  return (
    <AppLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Caixa / PDV</h1>
            <p className="text-muted-foreground text-sm mt-1">Registre vendas e dê baixa automática no estoque</p>
          </div>
          <Button variant="outline" onClick={() => setShowHistory(!showHistory)}>{showHistory ? 'Voltar ao Caixa' : 'Histórico de Vendas'}</Button>
        </div>

        {showHistory ? (
          <div className="rounded-xl border border-border bg-card overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead><tr className="border-b border-border bg-accent/50">
                  <th className="text-left p-3 font-medium text-muted-foreground">Venda</th>
                  <th className="text-left p-3 font-medium text-muted-foreground">Cliente</th>
                  <th className="text-left p-3 font-medium text-muted-foreground">Data</th>
                  <th className="text-right p-3 font-medium text-muted-foreground">Itens</th>
                  <th className="text-right p-3 font-medium text-muted-foreground">Total</th>
                </tr></thead>
                <tbody>
                  {[...sales].reverse().map(s => (
                    <tr key={s.id} className="border-b border-border last:border-0 hover:bg-accent/30 transition-colors">
                      <td className="p-3 font-medium text-foreground">#{s.id.substring(0,6)}</td>
                      <td className="p-3 text-muted-foreground">{s.customerName || '—'}</td>
                      <td className="p-3 text-muted-foreground">{new Date(s.createdAt).toLocaleString('pt-BR')}</td>
                      <td className="p-3 text-right text-muted-foreground">{s.items.length}</td>
                      <td className="p-3 text-right font-semibold text-foreground">{fmt(s.total)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            {sales.length === 0 && <div className="p-8 text-center text-muted-foreground">Nenhuma venda registrada.</div>}
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
            <div className="lg:col-span-3 space-y-4">
              <form onSubmit={handleBarcode} className="flex gap-2">
                <div className="relative flex-1">
                  <Barcode className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input ref={barcodeRef} value={barcodeInput} onChange={e => setBarcodeInput(e.target.value)} placeholder="Ler código de barras..." className="pl-10" autoFocus />
                </div>
                <Button type="submit" variant="outline">Buscar</Button>
              </form>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input value={search} onChange={e => setSearch(e.target.value)} placeholder="Buscar produto por nome..." className="pl-10" />
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {filtered.slice(0, 12).map(p => (
                  <button key={p.id} onClick={() => addToCart(p)} className="rounded-xl border border-border bg-card p-3 text-left hover:bg-accent/50 transition-colors">
                    <p className="text-sm font-medium text-foreground truncate">{p.name}</p>
                    <p className="text-xs text-muted-foreground mt-0.5">{p.stock} em estoque</p>
                    <p className="text-sm font-bold text-primary mt-1">{fmt(p.salePrice)}</p>
                  </button>
                ))}
              </div>
            </div>

            <div className="lg:col-span-2">
              <div className="rounded-xl border border-border bg-card p-4 sticky top-4">
                <div className="flex items-center gap-2 mb-4">
                  <ShoppingCart className="h-5 w-5 text-primary" />
                  <h3 className="font-semibold text-foreground">Carrinho</h3>
                  <span className="text-xs text-muted-foreground ml-auto">{cart.length} itens</span>
                </div>

                {/* Customer selection */}
                <div className="mb-3">
                  <select value={selectedCustomer?.id || ''} onChange={e => setSelectedCustomer(customers.find(c => c.id === e.target.value) || null)} className="w-full h-9 border border-input rounded-md px-3 bg-background text-foreground text-sm">
                    <option value="">Cliente (opcional)</option>
                    {customers.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                  </select>
                </div>

                {cart.length === 0 ? (
                  <p className="text-sm text-muted-foreground text-center py-8">Nenhum item adicionado</p>
                ) : (
                  <div className="space-y-2 max-h-80 overflow-y-auto">
                    {cart.map(item => (
                      <div key={item.productId} className="flex items-center gap-2 rounded-lg bg-accent/50 p-2">
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium text-foreground truncate">{item.productName}</p>
                          <p className="text-xs text-muted-foreground">{fmt(item.unitPrice)} un</p>
                        </div>
                        <div className="flex items-center gap-1">
                          <button onClick={() => updateQty(item.productId, -1)} className="p-1 rounded hover:bg-accent text-muted-foreground"><Minus className="h-3.5 w-3.5" /></button>
                          <span className="text-sm font-medium w-6 text-center text-foreground">{item.quantity}</span>
                          <button onClick={() => updateQty(item.productId, 1)} className="p-1 rounded hover:bg-accent text-muted-foreground"><Plus className="h-3.5 w-3.5" /></button>
                        </div>
                        <p className="text-sm font-semibold text-foreground w-20 text-right">{fmt(item.subtotal)}</p>
                        <button onClick={() => removeFromCart(item.productId)} className="p-1 text-muted-foreground hover:text-destructive"><Trash2 className="h-3.5 w-3.5" /></button>
                      </div>
                    ))}
                  </div>
                )}

                <div className="border-t border-border mt-4 pt-4">
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-sm font-medium text-muted-foreground">Total</span>
                    <span className="text-2xl font-bold text-foreground">{fmt(total)}</span>
                  </div>
                  <Button onClick={finalizeSale} className="w-full gap-2" size="lg" disabled={cart.length === 0}>
                    <CheckCircle className="h-5 w-5" /> Finalizar Venda
                  </Button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </AppLayout>
  );
}
