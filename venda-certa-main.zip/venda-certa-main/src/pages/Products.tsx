import { useEffect, useState } from 'react';
import AppLayout from '@/components/AppLayout';
import { getProducts, addProduct, updateProduct, deleteProduct, calcMargin, type Product } from '@/lib/store';
import { Plus, Pencil, Trash2, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';

function fmt(v: number) {
  return v.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
}

const emptyForm = { name: '', category: '', costPrice: 0, salePrice: 0, stock: 0, minStock: 5, unit: 'un', barcode: '' };

export default function Products() {
  const [products, setProducts] = useState<Product[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [form, setForm] = useState(emptyForm);

  const reload = () => setProducts(getProducts());
  useEffect(reload, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name.trim()) { toast.error('Nome é obrigatório'); return; }
    if (editId) {
      updateProduct(editId, form);
      toast.success('Produto atualizado');
    } else {
      addProduct(form);
      toast.success('Produto cadastrado');
    }
    setForm(emptyForm);
    setShowForm(false);
    setEditId(null);
    reload();
  };

  const handleEdit = (p: Product) => {
    setForm({ name: p.name, category: p.category, costPrice: p.costPrice, salePrice: p.salePrice, stock: p.stock, minStock: p.minStock, unit: p.unit, barcode: p.barcode || '' });
    setEditId(p.id);
    setShowForm(true);
  };

  const handleDelete = (id: string) => {
    deleteProduct(id);
    toast.success('Produto removido');
    reload();
  };

  return (
    <AppLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Produtos</h1>
            <p className="text-muted-foreground text-sm mt-1">Cadastre e gerencie seus produtos</p>
          </div>
          <Button onClick={() => { setForm(emptyForm); setEditId(null); setShowForm(true); }} className="gap-2">
            <Plus className="h-4 w-4" /> Novo Produto
          </Button>
        </div>

        {/* Form modal */}
        {showForm && (
          <div className="fixed inset-0 bg-black/20 z-50 flex items-center justify-center p-4" onClick={() => setShowForm(false)}>
            <div className="bg-card rounded-xl border border-border p-6 w-full max-w-md shadow-lg" onClick={e => e.stopPropagation()}>
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold">{editId ? 'Editar' : 'Novo'} Produto</h2>
                <button onClick={() => setShowForm(false)}><X className="h-5 w-5 text-muted-foreground" /></button>
              </div>
              <form onSubmit={handleSubmit} className="space-y-3">
                <div>
                  <Label>Nome</Label>
                  <Input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} placeholder="Ex: Camiseta Básica" />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label>Categoria</Label>
                    <Input value={form.category} onChange={e => setForm({ ...form, category: e.target.value })} placeholder="Ex: Vestuário" />
                  </div>
                  <div>
                    <Label>Código de Barras</Label>
                    <Input value={form.barcode} onChange={e => setForm({ ...form, barcode: e.target.value })} placeholder="Ex: 7891234560011" />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label>Unidade</Label>
                    <Input value={form.unit} onChange={e => setForm({ ...form, unit: e.target.value })} placeholder="un, kg, par" />
                  </div>
                  <div>
                    <Label>Preço de Custo (R$)</Label>
                    <Input type="number" step="0.01" value={form.costPrice || ''} onChange={e => setForm({ ...form, costPrice: parseFloat(e.target.value) || 0 })} />
                  </div>
                  <div>
                    <Label>Preço de Venda (R$)</Label>
                    <Input type="number" step="0.01" value={form.salePrice || ''} onChange={e => setForm({ ...form, salePrice: parseFloat(e.target.value) || 0 })} />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label>Estoque Atual</Label>
                    <Input type="number" value={form.stock || ''} onChange={e => setForm({ ...form, stock: parseInt(e.target.value) || 0 })} />
                  </div>
                  <div>
                    <Label>Estoque Mínimo</Label>
                    <Input type="number" value={form.minStock || ''} onChange={e => setForm({ ...form, minStock: parseInt(e.target.value) || 0 })} />
                  </div>
                </div>
                <Button type="submit" className="w-full mt-2">{editId ? 'Salvar Alterações' : 'Cadastrar Produto'}</Button>
              </form>
            </div>
          </div>
        )}

        {/* Table */}
        <div className="rounded-xl border border-border bg-card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border bg-accent/50">
                  <th className="text-left p-3 font-medium text-muted-foreground">Produto</th>
                  <th className="text-left p-3 font-medium text-muted-foreground">Categoria</th>
                  <th className="text-right p-3 font-medium text-muted-foreground">Custo</th>
                  <th className="text-right p-3 font-medium text-muted-foreground">Venda</th>
                  <th className="text-right p-3 font-medium text-muted-foreground">Margem</th>
                  <th className="text-right p-3 font-medium text-muted-foreground">Estoque</th>
                  <th className="text-right p-3 font-medium text-muted-foreground">Ações</th>
                </tr>
              </thead>
              <tbody>
                {products.map(p => {
                  const margin = calcMargin(p);
                  const lowStock = p.stock <= p.minStock;
                  return (
                    <tr key={p.id} className="border-b border-border last:border-0 hover:bg-accent/30 transition-colors">
                      <td className="p-3 font-medium text-foreground">{p.name}</td>
                      <td className="p-3 text-muted-foreground">{p.category}</td>
                      <td className="p-3 text-right text-muted-foreground">{fmt(p.costPrice)}</td>
                      <td className="p-3 text-right font-medium">{fmt(p.salePrice)}</td>
                      <td className={cn("p-3 text-right font-semibold", margin < 15 ? 'text-destructive' : margin < 30 ? 'text-amber-600' : 'text-emerald-600')}>
                        {margin.toFixed(1)}%
                      </td>
                      <td className={cn("p-3 text-right", lowStock && 'text-destructive font-semibold')}>
                        {p.stock} {p.unit}
                      </td>
                      <td className="p-3 text-right">
                        <div className="flex items-center justify-end gap-1">
                          <button onClick={() => handleEdit(p)} className="p-1.5 rounded-md hover:bg-accent text-muted-foreground hover:text-foreground transition-colors">
                            <Pencil className="h-3.5 w-3.5" />
                          </button>
                          <button onClick={() => handleDelete(p.id)} className="p-1.5 rounded-md hover:bg-destructive/10 text-muted-foreground hover:text-destructive transition-colors">
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          {products.length === 0 && (
            <div className="p-8 text-center text-muted-foreground">Nenhum produto cadastrado.</div>
          )}
        </div>
      </div>
    </AppLayout>
  );
}
