import { useEffect, useState } from 'react';
import AppLayout from '@/components/AppLayout';
import KpiCard from '@/components/KpiCard';
import { Package, DollarSign, TrendingUp, AlertTriangle, Wallet, HandCoins, CreditCard, Target, ShoppingCart, BarChart3 } from 'lucide-react';
import { getProducts, getSales, calcTotalFixedCostMonthly, calcMargin, calcGrossProfit, seedDemoData, getCashFlowSummary, getReceivables, getPurchases, getGoals, getProductPerformance, type Product, fmt } from '@/lib/store';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { cn } from '@/lib/utils';
import { Link } from 'react-router-dom';

export default function Index() {
  const [products, setProducts] = useState<Product[]>([]);

  useEffect(() => {
    seedDemoData();
    setProducts(getProducts());
  }, []);

  const now = new Date();
  const currentMonth = now.getMonth() + 1;
  const currentYear = now.getFullYear();

  const totalProducts = products.length;
  const lowStockCount = products.filter(p => p.stock <= p.minStock).length;
  const avgMargin = products.length > 0 ? products.reduce((s, p) => s + calcMargin(p), 0) / products.length : 0;

  // Financial
  const cashSummary = getCashFlowSummary();
  const receivables = getReceivables().filter(r => r.status !== 'recebida');
  const totalReceivable = receivables.reduce((s, r) => s + (r.totalValue - r.receivedValue), 0);
  const payables = getPurchases().filter(p => p.status !== 'pago');
  const totalPayable = payables.reduce((s, p) => s + (p.totalValue - p.paidValue), 0);

  // Sales this month
  const sales = getSales();
  const monthSales = sales.filter(s => { const d = new Date(s.createdAt); return d.getMonth() + 1 === currentMonth && d.getFullYear() === currentYear; });
  const monthRevenue = monthSales.reduce((s, sale) => s + sale.total, 0);
  const perf = getProductPerformance();
  const monthProfit = monthSales.reduce((s, sale) => s + sale.items.reduce((si, item) => { const p = perf.find(pr => pr.id === item.productId); return si + (p ? p.grossProfit * item.quantity : 0); }, 0), 0);

  // Goals
  const goals = getGoals().filter(g => g.month === currentMonth && g.year === currentYear);
  const revenueGoal = goals.find(g => g.type === 'faturamento');

  // Charts
  const marginData = products.map(p => ({
    name: p.name.length > 10 ? p.name.substring(0, 10) + '…' : p.name,
    margem: parseFloat(calcMargin(p).toFixed(1)),
  }));

  const categories: Record<string, number> = {};
  products.forEach(p => { categories[p.category] = (categories[p.category] || 0) + 1; });
  const categoryData = Object.entries(categories).map(([name, value]) => ({ name, value }));
  const pieColors = ['hsl(220,70%,50%)', 'hsl(142,71%,45%)', 'hsl(38,92%,50%)', 'hsl(280,65%,60%)', 'hsl(0,72%,51%)'];

  // Stalled products
  const stalledProducts = perf.filter(p => p.daysSinceLastSale > 30 && p.stock > 0);
  const lossProducts = perf.filter(p => p.margin < 0);

  return (
    <AppLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Dashboard</h1>
          <p className="text-muted-foreground text-sm mt-1">Visão geral do seu negócio</p>
        </div>

        {/* Financial KPIs */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          <div className="rounded-xl border border-border bg-card p-4">
            <p className="text-xs text-muted-foreground">Saldo Caixa</p>
            <p className={cn("text-lg font-bold mt-1", cashSummary.balanceTotal >= 0 ? 'text-emerald-600' : 'text-destructive')}>{fmt(cashSummary.balanceTotal)}</p>
          </div>
          <div className="rounded-xl border border-border bg-card p-4">
            <p className="text-xs text-muted-foreground">A Receber</p>
            <p className="text-lg font-bold text-primary mt-1">{fmt(totalReceivable)}</p>
          </div>
          <div className="rounded-xl border border-border bg-card p-4">
            <p className="text-xs text-muted-foreground">A Pagar</p>
            <p className="text-lg font-bold text-amber-600 mt-1">{fmt(totalPayable)}</p>
          </div>
          <div className="rounded-xl border border-border bg-card p-4">
            <p className="text-xs text-muted-foreground">Faturamento Mês</p>
            <p className="text-lg font-bold text-foreground mt-1">{fmt(monthRevenue)}</p>
          </div>
          <div className="rounded-xl border border-border bg-card p-4">
            <p className="text-xs text-muted-foreground">Lucro Mês</p>
            <p className={cn("text-lg font-bold mt-1", monthProfit >= 0 ? 'text-emerald-600' : 'text-destructive')}>{fmt(monthProfit)}</p>
          </div>
          <div className="rounded-xl border border-border bg-card p-4">
            <p className="text-xs text-muted-foreground">Margem Média</p>
            <p className="text-lg font-bold text-foreground mt-1">{avgMargin.toFixed(1)}%</p>
          </div>
        </div>

        {/* Goal progress */}
        {revenueGoal && (
          <div className="rounded-xl border border-border bg-card p-4">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2"><Target className="h-4 w-4 text-primary" /><span className="text-sm font-semibold text-foreground">Meta do Mês</span></div>
              <Link to="/metas" className="text-xs text-primary hover:underline">Ver metas →</Link>
            </div>
            <div className="flex items-center gap-4">
              <div className="flex-1">
                <div className="h-2.5 bg-accent rounded-full overflow-hidden">
                  <div className={cn("h-full rounded-full", monthRevenue >= revenueGoal.targetValue ? 'bg-emerald-500' : 'bg-primary')} style={{ width: `${Math.min(100, (monthRevenue / revenueGoal.targetValue) * 100)}%` }} />
                </div>
              </div>
              <span className="text-sm font-medium text-foreground">{((monthRevenue / revenueGoal.targetValue) * 100).toFixed(0)}%</span>
              <span className="text-xs text-muted-foreground">{fmt(monthRevenue)} / {fmt(revenueGoal.targetValue)}</span>
            </div>
          </div>
        )}

        {/* Summary cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <KpiCard icon={Package} title="Produtos" value={String(totalProducts)} subtitle={`${products.reduce((s, p) => s + p.stock, 0)} un em estoque`} color="primary" />
          <KpiCard icon={ShoppingCart} title="Vendas do Mês" value={String(monthSales.length)} subtitle={fmt(monthRevenue)} color="success" />
          <KpiCard icon={AlertTriangle} title="Estoque Baixo" value={String(lowStockCount)} subtitle="Abaixo do mínimo" color={lowStockCount > 0 ? 'destructive' : 'primary'} />
          <KpiCard icon={DollarSign} title="Custos Fixos/mês" value={fmt(calcTotalFixedCostMonthly())} subtitle="Total mensal" color="warning" />
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          <div className="lg:col-span-2 rounded-xl border border-border bg-card p-5">
            <h3 className="text-sm font-semibold text-foreground mb-4">Margem por Produto (%)</h3>
            <div className="h-56">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={marginData} margin={{ top: 0, right: 0, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(220,13%,91%)" />
                  <XAxis dataKey="name" tick={{ fontSize: 11, fill: 'hsl(220,10%,46%)' }} />
                  <YAxis tick={{ fontSize: 11, fill: 'hsl(220,10%,46%)' }} />
                  <Tooltip contentStyle={{ borderRadius: 8, border: '1px solid hsl(220,13%,91%)', fontSize: 12 }} formatter={(value: number) => [`${value}%`, 'Margem']} />
                  <Bar dataKey="margem" fill="hsl(220,70%,50%)" radius={[6, 6, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
          <div className="rounded-xl border border-border bg-card p-5">
            <h3 className="text-sm font-semibold text-foreground mb-4">Por Categoria</h3>
            <div className="h-56 flex items-center justify-center">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={categoryData} cx="50%" cy="50%" innerRadius={45} outerRadius={75} dataKey="value" paddingAngle={3}>
                    {categoryData.map((_, i) => (<Cell key={i} fill={pieColors[i % pieColors.length]} />))}
                  </Pie>
                  <Tooltip contentStyle={{ borderRadius: 8, border: '1px solid hsl(220,13%,91%)', fontSize: 12 }} />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="flex flex-wrap gap-3 mt-1 justify-center">
              {categoryData.map((c, i) => (
                <div key={c.name} className="flex items-center gap-1.5 text-xs text-muted-foreground">
                  <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: pieColors[i % pieColors.length] }} />
                  {c.name}
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Alerts */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {lowStockCount > 0 && (
            <div className="rounded-xl border border-destructive/30 bg-destructive/5 p-4">
              <div className="flex items-center gap-2 mb-2">
                <AlertTriangle className="h-4 w-4 text-destructive" />
                <h3 className="text-sm font-semibold text-destructive">Estoque Baixo</h3>
                <Link to="/reposicao" className="text-xs text-destructive hover:underline ml-auto">Ver reposição →</Link>
              </div>
              <div className="space-y-1">
                {products.filter(p => p.stock <= p.minStock).slice(0, 5).map(p => (
                  <p key={p.id} className="text-sm text-muted-foreground"><span className="font-medium text-foreground">{p.name}</span> — {p.stock} {p.unit} (mín: {p.minStock})</p>
                ))}
              </div>
            </div>
          )}
          {lossProducts.length > 0 && (
            <div className="rounded-xl border border-destructive/30 bg-destructive/5 p-4">
              <div className="flex items-center gap-2 mb-2">
                <BarChart3 className="h-4 w-4 text-destructive" />
                <h3 className="text-sm font-semibold text-destructive">Produtos no Prejuízo</h3>
                <Link to="/rentabilidade" className="text-xs text-destructive hover:underline ml-auto">Ver detalhes →</Link>
              </div>
              <div className="space-y-1">
                {lossProducts.slice(0, 5).map(p => (
                  <p key={p.id} className="text-sm text-muted-foreground"><span className="font-medium text-foreground">{p.name}</span> — margem {p.margin.toFixed(1)}%</p>
                ))}
              </div>
            </div>
          )}
          {stalledProducts.length > 0 && (
            <div className="rounded-xl border border-amber-300/30 bg-amber-50 p-4">
              <div className="flex items-center gap-2 mb-2">
                <Package className="h-4 w-4 text-amber-600" />
                <h3 className="text-sm font-semibold text-amber-700">Produtos Parados</h3>
              </div>
              <div className="space-y-1">
                {stalledProducts.slice(0, 5).map(p => (
                  <p key={p.id} className="text-sm text-muted-foreground"><span className="font-medium text-foreground">{p.name}</span> — {p.daysSinceLastSale} dias sem vender ({p.stock} em estoque)</p>
                ))}
              </div>
            </div>
          )}
          {payables.filter(p => p.status === 'atrasado').length > 0 && (
            <div className="rounded-xl border border-destructive/30 bg-destructive/5 p-4">
              <div className="flex items-center gap-2 mb-2">
                <CreditCard className="h-4 w-4 text-destructive" />
                <h3 className="text-sm font-semibold text-destructive">Contas Atrasadas</h3>
                <Link to="/contas-pagar" className="text-xs text-destructive hover:underline ml-auto">Ver todas →</Link>
              </div>
              <div className="space-y-1">
                {payables.filter(p => p.status === 'atrasado').slice(0, 3).map(p => (
                  <p key={p.id} className="text-sm text-muted-foreground"><span className="font-medium text-foreground">{p.supplierName}</span> — {fmt(p.totalValue - p.paidValue)}</p>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </AppLayout>
  );
}
